n=int(input("nhap vao 1 so tu 1-99: "))
while n<1 or n>99:
    n=int(input("nhap lai n, n chi duoc phep tu 1 -99:"))
print(f"so ban vua nhap la {n}")