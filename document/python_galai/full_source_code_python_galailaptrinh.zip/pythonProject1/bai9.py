dtb=float(input("Nhap vao diem trung binh: "))
if dtb>=7.5:
    print("ban da do DH")
else:
    print("ban da toach")
