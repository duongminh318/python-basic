tg1 = float(input("Nhap vao thoi gian ve dich cua vdv 1: "))
tg2 = float(input("Nhap vao thoi gian ve dich cua vdv 2: "))
tg3 = float(input("Nhap vao thoi gian ve dich cua vdv 3: "))
Dtb = (tg1+tg2+tg3)/3
print(f"Thoi gian trung binh cong ve dich cua 3 van dong vien la : {Dtb}")
print("Thoi gian trung binh cong ve dich cua 3 van dong vien la : ", round(Dtb,3))