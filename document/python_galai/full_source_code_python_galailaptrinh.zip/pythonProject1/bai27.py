lst= [3,8,10,3,4,9,9]
print(lst)
del lst
print(lst)