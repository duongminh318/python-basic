n= int(input("Moi nhap vao 1 so : "))
ktra = n%2
if ktra==0:
    print(f"{n} la so chan")
else:
    print(n, "la so le ")