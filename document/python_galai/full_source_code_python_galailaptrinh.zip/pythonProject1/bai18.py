s="1+2+3+4+5"
print(type(s))
print(eval(s))