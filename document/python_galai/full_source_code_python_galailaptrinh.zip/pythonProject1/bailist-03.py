from math import sqrt
quest = ["2 + 5 + 7 =","5 * 10 =","sqrt(16) =","12%2 =","5//2="]
for i in quest:
    answer = i.strip("=")
    traloi=float(input(i))




