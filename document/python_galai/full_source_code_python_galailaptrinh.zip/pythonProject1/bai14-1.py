sum=0
for n in range(1,6,2): #1,3,5
    if n==5:
        break
    sum+=n #sum=sum +n
print(sum)