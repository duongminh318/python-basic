#nhập vào số n, tính tổng từ 1 đến n
n=int(input("Nhập vào số n: "))
i=1
s=0
while i<=n:
    s=s+i
    i=i+1
print(s)