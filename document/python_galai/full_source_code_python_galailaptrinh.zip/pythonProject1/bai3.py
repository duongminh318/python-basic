""" ascascascasc
ascascasc
ascascasc
ascascdgsdeg
dsasdfgasdg
asdgasdgasdgasdg
"""

'''asfasfasf
asfasfasfasf
asfasfasfasfa
sfa
sf'''


a = float(input("nhap vao 1 so : "))
a=a+5
print(a)
print(type(a))