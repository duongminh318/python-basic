a=7
b=6
if a==b:
    print("a bang b")
else:
    print("a o bang b")

