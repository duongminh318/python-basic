vidu="11111111aaaaaaaaaabcsssssss"
print(vidu.find("A"))