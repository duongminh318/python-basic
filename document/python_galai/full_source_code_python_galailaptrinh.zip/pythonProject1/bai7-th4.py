x=4
y=2

x*=3  #x=3*x
"""
x-=y+7  #x=x-(y+7)
print(x)
# a

x+=9
print(x)

x=x/2
print(x)
x/=2
print(x)

x=x-1
print(x)


x-=1
print(x)"""
