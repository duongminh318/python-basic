import time
giay=time.time()
print(giay)

hienta=time.ctime(0)
print(hienta)

print("moi nhap vao dap an ")

print("het gio roi")

thoigian3=time.localtime()
print(thoigian3)
print("nam hien tai la ", thoigian3.tm_year)
print("thang hien tai la ", thoigian3.tm_mon)
