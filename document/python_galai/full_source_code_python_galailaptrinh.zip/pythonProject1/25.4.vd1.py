a="Hello"
s=""
for i in a:
    s=s+i+i
    print(s)



"""b="university of technology and education"
a2=""
for i in range(len(b)):
    if b[i]=="a":
        a2=a2+" "+str(i)
print("vi tri cua ky tu a la:", a2)"""