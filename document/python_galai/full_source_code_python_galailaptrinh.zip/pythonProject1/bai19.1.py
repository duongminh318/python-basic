def Xuatchuoi(chuoi):
    print(chuoi)

chuoi=input("nhap 1 chuoi")

Xuatchuoi(chuoi)
