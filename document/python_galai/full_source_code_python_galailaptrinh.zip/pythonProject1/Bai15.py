for i in range(2,10,1):
    for j in range(2,10):
        print(i,"*",j, "=" , i*j)
    print("-"*10)