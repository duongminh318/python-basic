"""n=float(input("nhap vao so diem trung binh cac mon thi dai hoc: "))
#diem trung binh dai hoc quoc gia ha noi khoa tin hoc : >= 7.5 do
if n >= 7.5:
    print("Ban hoc sinh da trung tuyen truong DHQG khoa toan tin")"""

diem_a =9
diem_b = 8
if diem_a<diem_b:
    print("ban hoc sinh a diem thap hon ban b")
if diem_a>diem_b:
    print("ban hoc sinh a diem CAO hon ban b")