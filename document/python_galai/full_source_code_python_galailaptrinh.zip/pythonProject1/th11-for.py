for i in range(1,51,1):
   '''if i%3==0:
        print(i,end=" ")'''
   if i%3!=0:
       continue
   print(i,end=" ")
